<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Accudelta FCPs</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-07-25T00:26:13</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>e2e7ef4e-cde9-46da-898b-25da97fe256d</testSuiteGuid>
   <testCaseLink>
      <guid>f3c0e609-9d59-47b2-b06a-d1301bf00192</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Accudelta FCP - Fund search</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>93cfc643-f0e7-4f62-83d2-73504bfb0f94</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Accudelta FCP URLs</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId>93cfc643-f0e7-4f62-83d2-73504bfb0f94</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>pageUrl</value>
         <variableId>569c6b0d-778e-4814-b3a9-e57bbe990fe1</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>53ea040b-c00f-460c-88ff-e131281a41ff</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Accudelta FCP - Recent data</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>7572e3d0-8271-423a-bf42-4073d6711c47</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Accudelta FCP URLs</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>888e5cf6-b503-49b2-a8c6-96bd7a29c94b</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>7572e3d0-8271-423a-bf42-4073d6711c47</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>pageUrl</value>
         <variableId>8ad4a686-c5fe-49c6-baa1-ea24c332218e</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
